#ifndef _ixtest_util_h_
#define _ixtest_util_h_

#ifndef _success_
#define _success_
const int success = 0;
#endif

#ifndef _fail_
#define _fail_
const int fail = -1;
#endif

#endif

